# LLC Student Registration System: 2-Developer Execution Plan

Based on the architecture, database design, and folder structure, here is a **day-by-day development plan** for two developers.

* **Developer 1 (Dev 1)**: Node.js/Express backend, MySQL schema, APIs.
* **Developer 2 (Dev 2)**: React frontend, UI components, state management.

---

## Phase 1: Project Setup & Foundation (Days 1-2)
*Goal: Repositories, folder structure, database schema.*

**Day 1: Scaffolding**
*   **Dev 1**: Initialize Node.js/Express app, folder structure from `fl-architecture.md`, `.env`, `app.js`, `server.js`, Helmet/CORS.
*   **Dev 2**: Initialize React (Vite, JavaScript), routing, global CSS (e.g., Tailwind), responsive layout shell.

**Day 2: Database & Core Configs**
*   **Dev 1**: Set up MySQL connection pool; write migrations for all tables in `database-design.md`; seed sample courses/batches and the admin (from env vars).
*   **Dev 2**: Build shared UI components (Button, Input, Select, Modal, Spinner, StatusBadge, Navbar). Configure Axios with credentials.

---

## Phase 2: Public Catalog (Days 3-4)
*Goal: Visitors can browse LLC courses and open batches.*

**Day 3: Catalog API & UI**
*   **Dev 1**: `/api/courses`, `/api/courses/{id}`, `/api/courses/{id}/batches`.
*   **Dev 2**: Home page, course list, course details with batch selector.

**Day 4: Admin Course & Batch Management API**
*   **Dev 1**: Admin endpoints to create/edit/activate/deactivate courses and batches; open/close registration.
*   **Dev 2**: Begin admin layout and course/batch management forms.

---

## Phase 3: Authentication (Days 5-6)
*Goal: Secure login, verification, recovery.*

**Day 5: Auth Core**
*   **Dev 1**: Password hashing, `/api/auth/login|logout|me`, JWT cookie, `requireAuth`/`requireRole` middleware, rate limiting.
*   **Dev 2**: Login page, auth context/store, protected routes (student/admin).

**Day 6: Verification & Recovery**
*   **Dev 1**: Email service; verification and password-reset token flows (hashed, expiring, single-use).
*   **Dev 2**: Verify-email, forgot-password, and reset-password pages.

---

## Phase 4: The Core Registration Engine (Days 7-10)
*Goal: Atomic, safe registration with unique numbers.*

**Day 7: Registration Transaction**
*   **Dev 1**: `/api/registrations/apply`: validate, recheck batch, single transaction (users, students, registrations), registration-number counter, rollback on error.
*   **Dev 2**: Combined account + registration form with client-side validation.

**Day 8: Integration & Failure Handling**
*   **Dev 1**: Tests: closed batch, duplicate email, duplicate batch, simulated mid-transaction failure (no partial rows), concurrent number generation.
*   **Dev 2**: Confirmation page showing registration number; clear error messages (no false success).

**Day 9: Student Dashboard API**
*   **Dev 1**: `/api/registrations/me`, `/api/students/me`, additional registration for another course, cancel pending; ownership enforcement.
*   **Dev 2**: Student dashboard: own registrations and statuses, profile view.

**Day 10: Buffer & Integration Day**
*   **Both**: End-to-end test: register, verify email, log in, view status; confirm one student cannot access another's data.

---

## Phase 5: Admin Operations (Days 11-13)
*Goal: Administrators can review and manage applications.*

**Day 11: Registration Review API**
*   **Dev 1**: `/api/admin/registrations` with search/filter/pagination (indexed queries); detail endpoint.
*   **Dev 2**: Admin registration table with filters (name, number, phone, course, batch, date, status).

**Day 12: Status Updates & History**
*   **Dev 1**: `PATCH /status` with history and audit log; optional status-change email.
*   **Dev 2**: Status update modal and registration detail view with history.

**Day 13: Stats & CSV Export**
*   **Dev 1**: `/api/admin/stats`; CSV export (escape formula-injection characters like `=`, `+`, `-`, `@`).
*   **Dev 2**: Dashboard stat cards and export button.

---

## Phase 6: QA, Security & Deployment (Days 14-16)
*Goal: Production readiness.*

**Day 14: Security Review**
*   **Both**: Verify every admin route rejects non-admins; verify students cannot read others' records; confirm no secrets in frontend bundle; test rate limits; check for SQL injection; test mobile responsiveness.

**Day 15: Deployment**
*   **Dev 1**: Provision VPS/hosting and MySQL; Nginx reverse proxy with HTTPS; Node via PM2; least-privilege DB user; automated backups.
*   **Dev 2**: Production React build served by Nginx; production environment variables.

**Day 16: Launch & Monitoring**
*   **Both**: Live testing against acceptance criteria; confirm the system stays online independently of any developer computer; monitor logs; test a backup restore.

---

### Tips for Collaboration
1. **API Contracts First**: Agree on JSON request/response shapes (`api-plan.md`) before building; document in Postman or Swagger.
2. **Mock APIs**: Dev 2 can use mock responses while Dev 1 finishes endpoints.
3. **Daily Sync**: 10 minutes each morning for progress and blockers.
4. **Migrations in Git**: Every schema change is a numbered SQL migration; never edit the live DB by hand.
